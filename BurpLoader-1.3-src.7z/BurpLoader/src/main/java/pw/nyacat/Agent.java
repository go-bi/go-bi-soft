package pw.nyacat;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import pw.nyacat.Patcher.SkipValid;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.Instrumentation;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.ProtectionDomain;


public class Agent {
    public static void premain(String agentOps, Instrumentation instrumentation) {
        instrument(instrumentation);
    }


    public static void agentmain(String agentOps, Instrumentation instrumentation) {
        instrument(instrumentation);
    }

    private static void instrument(Instrumentation instrumentation) {
        instrumentation.addTransformer(new PatcherTransformer());
    }

    private static void writeModifyClass(String className, byte[] classArray) {
        try {
            Path targetFile = Paths.get(Paths.get("out").toAbsolutePath().toString(), className.replace("/", ".") + ".class");
            System.out.println("Writing modified class: " + targetFile);
            DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(targetFile.toFile()));
            dataOutputStream.write(classArray);
            dataOutputStream.flush();
            dataOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class PatcherTransformer implements ClassFileTransformer {

        @Override
        public byte[] transform(ClassLoader classLoader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) {

            if (className.startsWith("burp/") && classLoader.getClass().getName().startsWith("burp.")) {
                ClassReader classReader = new ClassReader(classfileBuffer);
                if (classReader.getSuperName().equals("java/lang/Object")) {
                    ClassWriter classWriter = new ClassWriter(classReader, ClassWriter.COMPUTE_FRAMES);
                    SkipValid skipValid = new SkipValid(classWriter);
                    classReader.accept(skipValid, ClassReader.EXPAND_FRAMES);

                    return classWriter.toByteArray();
                }
            }
            return classfileBuffer;
        }
    }
}