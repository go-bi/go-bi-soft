package pw.nyacat.Patcher;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.util.Arrays;



public class SkipValid extends ClassVisitor {
    public SkipValid(ClassVisitor cv) {
        super(Opcodes.ASM9, cv);
    }

    public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
        // void a method -> skip valid
//        if ("a".equals(name) && "([Ljava/lang/Object;Ljava/lang/Object;)V".equals(desc)) {
        if (access == Opcodes.ACC_STATIC && "([Ljava/lang/Object;Ljava/lang/Object;)V".equals(desc) && Arrays.asList(exceptions).contains("java/lang/Exception")) {
            System.out.println("Modified method: " + name + " with: " + desc);
            MethodVisitor mv = this.cv.visitMethod(access, name, desc, signature, exceptions);
            return new DynamicMethodVisitor(mv);
        }
        if (this.cv != null) return this.cv.visitMethod(access, name, desc, signature, exceptions);
        return null;
    }

    private static class DynamicMethodVisitor extends MethodVisitor {
        private final MethodVisitor target;

        DynamicMethodVisitor(MethodVisitor mv) {
            super(Opcodes.ASM9, null);
            this.target = mv;
        }

        @Override
        public void visitCode() {
            target.visitCode();
            Label label0 = new Label();
            target.visitLabel(label0);
            target.visitLineNumber(18, label0);
            target.visitMethodInsn(Opcodes.INVOKESTATIC, "java/util/Base64", "getDecoder", "()Ljava/util/Base64$Decoder;", false);
            target.visitVarInsn(Opcodes.ALOAD, 0);
            target.visitInsn(Opcodes.ICONST_0);
            target.visitInsn(Opcodes.AALOAD);
            target.visitTypeInsn(Opcodes.CHECKCAST, "[B");
            target.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "java/util/Base64$Decoder", "decode", "([B)[B", false);
            target.visitVarInsn(Opcodes.ASTORE, 2);
            Label label1 = new Label();
            target.visitLabel(label1);
            target.visitLineNumber(20, label1);
            target.visitTypeInsn(Opcodes.NEW, "javax/crypto/spec/SecretKeySpec");
            target.visitInsn(Opcodes.DUP);
            target.visitLdcInsn("burpr0x!");
            target.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "java/lang/String", "getBytes", "()[B", false);
            target.visitLdcInsn("DES");
            target.visitMethodInsn(Opcodes.INVOKESPECIAL, "javax/crypto/spec/SecretKeySpec", "<init>", "([BLjava/lang/String;)V", false);
            target.visitVarInsn(Opcodes.ASTORE, 3);
            Label label2 = new Label();
            target.visitLabel(label2);
            target.visitLineNumber(21, label2);
            target.visitLdcInsn("DES");
            target.visitMethodInsn(Opcodes.INVOKESTATIC, "javax/crypto/Cipher", "getInstance", "(Ljava/lang/String;)Ljavax/crypto/Cipher;", false);
            target.visitVarInsn(Opcodes.ASTORE, 4);
            Label label3 = new Label();
            target.visitLabel(label3);
            target.visitLineNumber(22, label3);
            target.visitVarInsn(Opcodes.ALOAD, 4);
            target.visitInsn(Opcodes.ICONST_2);
            target.visitVarInsn(Opcodes.ALOAD, 3);
            target.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "javax/crypto/Cipher", "init", "(ILjava/security/Key;)V", false);
            Label label4 = new Label();
            target.visitLabel(label4);
            target.visitLineNumber(23, label4);
            target.visitVarInsn(Opcodes.ALOAD, 4);
            target.visitVarInsn(Opcodes.ALOAD, 2);
            target.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "javax/crypto/Cipher", "doFinal", "([B)[B", false);
            target.visitVarInsn(Opcodes.ASTORE, 5);
            Label label5 = new Label();
            target.visitLabel(label5);
            target.visitLineNumber(25, label5);
            target.visitTypeInsn(Opcodes.NEW, "java/lang/String");
            target.visitInsn(Opcodes.DUP);
            target.visitVarInsn(Opcodes.ALOAD, 5);
            target.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/String", "<init>", "([B)V", false);
            target.visitLdcInsn("\u0000");
            target.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "java/lang/String", "split", "(Ljava/lang/String;)[Ljava/lang/String;", false);
            target.visitVarInsn(Opcodes.ASTORE, 6);
            Label label6 = new Label();
            target.visitLabel(label6);
            target.visitLineNumber(28, label6);
            target.visitVarInsn(Opcodes.ALOAD, 6);
            target.visitInsn(Opcodes.ARRAYLENGTH);
            target.visitIntInsn(Opcodes.BIPUSH, 8);
            Label label7 = new Label();
            target.visitJumpInsn(Opcodes.IF_ICMPEQ, label7);
            target.visitVarInsn(Opcodes.ALOAD, 6);
            target.visitInsn(Opcodes.ARRAYLENGTH);
            target.visitIntInsn(Opcodes.BIPUSH, 7);
            Label label8 = new Label();
            target.visitJumpInsn(Opcodes.IF_ICMPNE, label8);
            target.visitLabel(label7);
            target.visitLineNumber(29, label7);
            target.visitFrame(Opcodes.F_FULL, 7, new Object[] {"[Ljava/lang/Object;", "java/lang/Object", "[B", "javax/crypto/spec/SecretKeySpec", "javax/crypto/Cipher", "[B", "[Ljava/lang/String;"}, 0, new Object[] {});
            target.visitIntInsn(Opcodes.BIPUSH, 6);
            target.visitVarInsn(Opcodes.ISTORE, 7);
            Label label9 = new Label();
            target.visitLabel(label9);
            Label label10 = new Label();
            target.visitJumpInsn(Opcodes.GOTO, label10);
            target.visitLabel(label8);
            target.visitLineNumber(30, label8);
            target.visitFrame(Opcodes.F_SAME, 0, null, 0, null);
            target.visitVarInsn(Opcodes.ALOAD, 6);
            target.visitInsn(Opcodes.ARRAYLENGTH);
            target.visitIntInsn(Opcodes.BIPUSH, 10);
            Label label11 = new Label();
            target.visitJumpInsn(Opcodes.IF_ICMPNE, label11);
            Label label12 = new Label();
            target.visitLabel(label12);
            target.visitLineNumber(31, label12);
            target.visitIntInsn(Opcodes.BIPUSH, 8);
            target.visitVarInsn(Opcodes.ISTORE, 7);
            Label label13 = new Label();
            target.visitLabel(label13);
            target.visitJumpInsn(Opcodes.GOTO, label10);
            target.visitLabel(label11);
            target.visitLineNumber(33, label11);
            target.visitFrame(Opcodes.F_SAME, 0, null, 0, null);
            target.visitTypeInsn(Opcodes.NEW, "java/lang/Exception");
            target.visitInsn(Opcodes.DUP);
            target.visitLdcInsn("BadMessageException");
            target.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Exception", "<init>", "(Ljava/lang/String;)V", false);
            target.visitInsn(Opcodes.ATHROW);
            target.visitLabel(label10);
            target.visitLineNumber(35, label10);
            target.visitFrame(Opcodes.F_APPEND,1, new Object[] {Opcodes.INTEGER}, 0, null);
            target.visitVarInsn(Opcodes.ILOAD, 7);
            target.visitTypeInsn(Opcodes.ANEWARRAY, "java/lang/String");
            target.visitVarInsn(Opcodes.ASTORE, 8);
            Label label14 = new Label();
            target.visitLabel(label14);
            target.visitLineNumber(36, label14);
            target.visitVarInsn(Opcodes.ALOAD, 6);
            target.visitInsn(Opcodes.ICONST_0);
            target.visitVarInsn(Opcodes.ALOAD, 8);
            target.visitInsn(Opcodes.ICONST_0);
            target.visitVarInsn(Opcodes.ILOAD, 7);
            target.visitMethodInsn(Opcodes.INVOKESTATIC, "java/lang/System", "arraycopy", "(Ljava/lang/Object;ILjava/lang/Object;II)V", false);
            Label label15 = new Label();
            target.visitLabel(label15);
            target.visitLineNumber(37, label15);
            target.visitVarInsn(Opcodes.ALOAD, 0);
            target.visitInsn(Opcodes.ICONST_0);
            target.visitVarInsn(Opcodes.ALOAD, 8);
            target.visitInsn(Opcodes.AASTORE);
            Label label16 = new Label();
            target.visitLabel(label16);
            target.visitLineNumber(38, label16);
            target.visitInsn(Opcodes.RETURN);
            Label label17 = new Label();
            target.visitLabel(label17);
            target.visitLocalVariable("outputSize", "I", null, label9, label8, 7);
            target.visitLocalVariable("outputSize", "I", null, label13, label11, 7);
            target.visitLocalVariable("var0", "[Ljava/lang/Object;", null, label0, label17, 0);
            target.visitLocalVariable("var1_1", "Ljava/lang/Object;", null, label0, label17, 1);
            target.visitLocalVariable("rawBytes", "[B", null, label1, label17, 2);
            target.visitLocalVariable("localSecretKeySpec", "Ljavax/crypto/spec/SecretKeySpec;", null, label2, label17, 3);
            target.visitLocalVariable("localCipher", "Ljavax/crypto/Cipher;", null, label3, label17, 4);
            target.visitLocalVariable("decodedBytes", "[B", null, label5, label17, 5);
            target.visitLocalVariable("outputString", "[Ljava/lang/String;", null, label6, label17, 6);
            target.visitLocalVariable("outputSize", "I", null, label10, label17, 7);
            target.visitLocalVariable("outputData", "[Ljava/lang/String;", null, label14, label17, 8);
            target.visitMaxs(5, 9);
            target.visitEnd();
        }
    }
}
