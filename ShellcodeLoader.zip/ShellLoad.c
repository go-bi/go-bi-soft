// ________________________________________________
//
// ShellLoad.c
//
// PURPOSE:
// Useful tool to test shellcodes.
// The program will load the shellcode from file and execute it into its own process memory.
// 3 different shellcode loading methods are provided as option.
//
// USAGE:
// Execute the program passing the shellcode file path as parameter.
// 2� parameter is optional and lets you define the preferred shellcode loading method:
// 1 = Inline ASM (Default)
// 2 = C Function
// 3 = CallWindowProc
//
//
// RELEASE NOTES:
// v1.0.0
// 27 Jul 2021
//
// AUTHOR:
// � BreakingSecurity.net 
// https://BreakingSecurity.net
// ________________________________________________


#include <Windows.h>
#include <stdio.h>

// Shellcode Entrypoint function prototype
// TIP: We can edit this function to support different return types and parameters
typedef INT(*ShellEntry)();

#define METHOD_INLINEASM 1
#define METHOD_CFUNCTION 2
#define METHOD_CALLWINDOWPROC 3


int main(int argc, char *argv[])
{
	int ret = 0;
	int mtd = 1;
	int err = 0;
	DWORD fsize = 0;

	printf("\n");
	printf("-------------------------\n");
	printf(" Shellcode Loader v1.0.0\n");
	printf(" BreakingSecurity.net\n");
	printf("-------------------------\n");
	printf("\n");

	if (argc < 2)
	{
		printf("USAGE MODE:\n");
		printf("ShellLoad.exe path\n");
		printf("ShellLoad.exe path method\n");
		printf("\n");
		printf("METHODS:\n");
		printf("1 = Inline ASM (default)\n");
		printf("2 = C Function\n");
		printf("3 = CallWindowProc\n\n");
		printf("EXAMPLE (default method): ShellLoad.exe \"C:\\shellcode.file\" \n");
		printf("EXAMPLE (select method): ShellLoad.exe \"C:\\shellcode.file\" 1\n");
		printf("------------------------\n");

		printf("\n[-] ERROR: No parameter passed. Path to shellcode is required.\n\n");
		_getch();
		return 0;
	}

	if (argc > 2)
	{
		mtd = atoi(argv[2]);
	}

	printf("[+] Opening file: %s\n", argv[1]);

	HANDLE hFile = CreateFileA(argv[1], GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if (hFile == INVALID_HANDLE_VALUE) 
	{
		err = GetLastError();
		printf("[-] ERROR: Unable to open file. Error %i\n", err);
		return 0;
	}

	fsize = GetFileSize(hFile, NULL);

	if (fsize == INVALID_FILE_SIZE) 
	{
		err = GetLastError();
		printf("[-] ERROR: GetFileSize error %i\n", err);
		CloseHandle(hFile);
		return 0;
	}

	printf("[+] File Size: %i bytes\n", fsize);
	printf("[+] Allocating memory buffer...\n");

	void* pShellcode = VirtualAlloc(NULL, fsize, MEM_COMMIT, PAGE_EXECUTE_READWRITE);

	if (pShellcode == NULL) 
	{
		err = GetLastError();
		printf("[-] ERROR: VirtualAlloc error %i\n", err);
		CloseHandle(hFile);
		return 0;
	}

	printf("[+] Reading file...\n");

	DWORD nBytesRead = 0;
	ReadFile(hFile, pShellcode, fsize, &nBytesRead, NULL);
	CloseHandle(hFile);

	switch (mtd)
	{
		case METHOD_INLINEASM:
		{
			printf("[+] Executing shellcode (method: Inline ASM)\n");

			__asm
			{
				call pShellcode	// Execute shellcode entrypoint
				mov ret, eax	// Retrieve return value
			}
			break;
		}
		case METHOD_CFUNCTION:
		{
			printf("[+] Executing shellcode (method: C Function)\n");

			ShellEntry fShellcode = (ShellEntry)pShellcode;
			ret = fShellcode();
			break;
		}
		case METHOD_CALLWINDOWPROC:
		{
			printf("[+] Executing shellcode (method: CallWindowProc)\n");

			// TIP: we can use CallWindowProc parameters to pass arguments to our function
			ret = CallWindowProcA((WNDPROC)pShellcode, 0, 0, 0, 0);
			break;
		}
	}

	printf("[+] Shellcode executed!\n");
	_getch(); // Keep shellcode running
	return ret;
}
