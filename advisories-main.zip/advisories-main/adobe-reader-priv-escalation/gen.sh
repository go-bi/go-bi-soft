./build.py --enable_i686 ./export.txt
